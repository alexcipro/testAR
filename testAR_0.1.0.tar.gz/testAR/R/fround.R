
fround <- function(x) {
  return(floor(x+.5))
}

